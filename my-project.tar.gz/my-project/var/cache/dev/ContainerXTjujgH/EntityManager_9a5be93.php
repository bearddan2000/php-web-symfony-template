<?php

namespace ContainerXTjujgH;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder92def = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer650d9 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesa904d = [
        
    ];

    public function getConnection()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getConnection', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getMetadataFactory', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getExpressionBuilder', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'beginTransaction', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getCache', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getCache();
    }

    public function transactional($func)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'transactional', array('func' => $func), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'wrapInTransaction', array('func' => $func), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'commit', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->commit();
    }

    public function rollback()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'rollback', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getClassMetadata', array('className' => $className), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'createQuery', array('dql' => $dql), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'createNamedQuery', array('name' => $name), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'createQueryBuilder', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'flush', array('entity' => $entity), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'clear', array('entityName' => $entityName), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->clear($entityName);
    }

    public function close()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'close', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->close();
    }

    public function persist($entity)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'persist', array('entity' => $entity), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'remove', array('entity' => $entity), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'refresh', array('entity' => $entity), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'detach', array('entity' => $entity), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'merge', array('entity' => $entity), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getRepository', array('entityName' => $entityName), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'contains', array('entity' => $entity), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getEventManager', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getConfiguration', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'isOpen', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getUnitOfWork', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getProxyFactory', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'initializeObject', array('obj' => $obj), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'getFilters', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'isFiltersStateClean', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'hasFilters', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return $this->valueHolder92def->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer650d9 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder92def) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder92def = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder92def->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, '__get', ['name' => $name], $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        if (isset(self::$publicPropertiesa904d[$name])) {
            return $this->valueHolder92def->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder92def;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder92def;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder92def;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder92def;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, '__isset', array('name' => $name), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder92def;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder92def;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, '__unset', array('name' => $name), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder92def;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder92def;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, '__clone', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        $this->valueHolder92def = clone $this->valueHolder92def;
    }

    public function __sleep()
    {
        $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, '__sleep', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;

        return array('valueHolder92def');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer650d9 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer650d9;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer650d9 && ($this->initializer650d9->__invoke($valueHolder92def, $this, 'initializeProxy', array(), $this->initializer650d9) || 1) && $this->valueHolder92def = $valueHolder92def;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder92def;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder92def;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
